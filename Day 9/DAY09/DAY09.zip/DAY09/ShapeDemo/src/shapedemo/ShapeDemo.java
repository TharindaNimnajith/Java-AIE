package shapedemo;
public class ShapeDemo {

    public static void main(String[] args) {
        
    }
    
}
