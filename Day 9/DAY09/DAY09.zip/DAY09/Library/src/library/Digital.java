package library;

public class Digital extends Media {
    String primary_category;
    String secondary_category;
}
