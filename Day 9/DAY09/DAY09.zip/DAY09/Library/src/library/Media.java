package library;
public class Media {
    
    String name;
    int num;
    boolean status;     //1-lendable 0-reference only
    
}
