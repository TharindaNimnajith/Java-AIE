package library;

public class Employee extends members {
    
    double Salary;
    
    public void calSalary(){
    
    }
    
}
