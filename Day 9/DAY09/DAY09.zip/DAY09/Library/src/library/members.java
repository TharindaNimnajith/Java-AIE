package library;

public class members {
    String name;
    int ID;
    
    public members(){
    
    }
    public members(String name,int ID){
    
    }
    
}
