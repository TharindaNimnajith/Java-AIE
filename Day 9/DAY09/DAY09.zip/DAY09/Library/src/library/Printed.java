package library;

public class Printed extends Media {
    String category;
}
