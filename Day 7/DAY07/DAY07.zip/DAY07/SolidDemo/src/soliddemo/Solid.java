package soliddemo;

public interface Solid {
    public double calVolume();
    public double calMass();
    public void printDetails();    
}
