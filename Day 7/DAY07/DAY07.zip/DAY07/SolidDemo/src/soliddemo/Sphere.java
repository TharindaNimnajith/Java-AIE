package soliddemo;

public class Sphere implements Solid {

    public double calVolume(){
        return 0;
    }
    public double calMass(){
        return 0;
    }
    public void printDetails(){
    
    } 
   
    
}
