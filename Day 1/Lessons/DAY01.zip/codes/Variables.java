public class Variables{
	
	
	public static void main(String args[]){
		
		int a=10,b=20;
		double c=40.56;
		String d="john";
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
	}
	
	
}