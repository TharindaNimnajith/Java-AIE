public class Test3{
	
	public static void main(String args[]){

		//int[] array={10,20,30,40,50,60,70,80};
		//in c int array[]
		
		String[] array={"John","William","Andrew","Maththew"};
		
		for(String x : array){
			System.out.println(x);
		}
		
//		for(int i=0;i<5,i++){
//			system.out.println(array[i]);
//		}
		
	}	
}